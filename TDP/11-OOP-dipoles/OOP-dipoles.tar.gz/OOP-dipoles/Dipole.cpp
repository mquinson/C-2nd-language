#include "Dipole.hpp"
#include <string>

std::ostream &operator<<(std::ostream &out, const Dipole &d) {
	std::string str = d.toString();
	out << str;
	return out;
}
