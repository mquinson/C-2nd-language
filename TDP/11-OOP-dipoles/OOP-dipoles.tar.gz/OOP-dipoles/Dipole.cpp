#include "Complex.hpp"

class Dipole {
	~Dipole() = default;

    virtual Complex impedance(double omega) = 0;
};

