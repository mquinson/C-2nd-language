#include <iostream>
#include "Serie.hpp"
#include "Capacitor.hpp"
#include "Inductor.hpp"
#include "Resistor.hpp"

int main() {
   Inductor c(5e-2);
   Resistor r(100);
   Serie s(&c, &r); 
   std::cout << s <<" has an impedance of "<< s.impedance(1000) 
      << " at frequency 1000 (should be 100 + 1570i)"<< std::endl;
}
