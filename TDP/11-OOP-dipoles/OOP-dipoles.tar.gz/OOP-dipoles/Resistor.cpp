#include "Resistor.hpp"
#include <sstream>

Resistor::Resistor(double resistance) {
}
Complex Resistor::impedance(double omega) {
    return Complex(0,0);  Not the right values here :(
}
std::string Resistor::toString() const {
	std::stringstream ss;
	ss << "Resistor"; // Fill it as if ss were cout, ie using the << operator
	return ss.str(); // return the built string
}
