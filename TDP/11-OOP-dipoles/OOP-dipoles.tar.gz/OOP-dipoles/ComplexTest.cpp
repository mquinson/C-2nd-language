#include "Complex.hpp"

int main(int argc, char**argv) {
   
   Complex c1(1,4); // c1 is  1 + 4i
   Complex c2(4,2); // c2 is  4 + 2i
   
   std::cout << "c1:" << c1 << std::endl;
   std::cout << "c2:" << c2 << std::endl;
}
