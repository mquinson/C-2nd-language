#ifndef DIPOLE_HPP
#define DIPOLE_HPP

#include "Complex.hpp"
#include <string>

class Dipole {
public:
	virtual ~Dipole() = default; // ignore that line for now ;)
	friend std::ostream &operator<<(std::ostream &out, const Dipole &d); // That one too

    virtual Complex impedance(double omega) = 0;
    virtual std::string toString() const = 0;
};

#endif
