#include "Serie.hpp"
#include "Dipole.hpp"
#include "Resistor.hpp"
#include "Capacitor.hpp"
#include <sstream>

Serie::Serie(Dipole* d1_, Dipole* d2_) {
}

Complex Serie::impedance(double omega) {
 return Complex(0, 0);
}

std::string Serie::toString() const {
	std::stringstream ss;
	ss << "Serie(" << *d1 << "," << *d2 << ")"; 
	return ss.str();
}
