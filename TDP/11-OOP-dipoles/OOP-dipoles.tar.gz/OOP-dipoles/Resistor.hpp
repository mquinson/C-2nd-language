#ifndef RESISTOR_HPP
#define RESISTOR_HPP

#include "Dipole.hpp"

class Resistor : public Dipole {
public:
    Resistor(double resistance);
    Complex impedance(double omega) override;
    std::string toString() const override;
};

#endif
