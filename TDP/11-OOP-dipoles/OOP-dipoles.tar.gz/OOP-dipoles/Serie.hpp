#include "Dipole.hpp"

class Serie : public Dipole {
public:
    Serie(Dipole* d1, Dipole* d2);
    Complex impedance(double omega) override;
    std::string toString() const override;
private:
    Dipole* d1; // my first dipole
    Dipole* d2; // my second dipole    
};
