#include <iostream>
#include "Inductor.hpp"

int main() {
	Inductor i(7e-2); // The inductor of the figure is 7 10e-2 H
	std::cout << "Impedance of "<< i << " at frequency 314 is "<< i.impedance(314)
			<< " (should be 0 + 21.98i)"<< std::endl;
}
