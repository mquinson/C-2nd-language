#include <iostream>
#include "Resistor.hpp"

int main() {
	Resistor r(1e2); // The resistor of the figure
	std::cout << r <<" Impedance: "<< r.impedance(1e2) << " (should be 100 + 0i)"<< std::endl;
}
