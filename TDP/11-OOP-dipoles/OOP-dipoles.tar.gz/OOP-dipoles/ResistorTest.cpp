#include <iostream>
#include "Resistor.hpp"

int main() {
	Resistor r(100); // The resistor of the figure is 100 Ohm
	std::cout << "Impedance of "<< r << " at frequency 314 is "<< r.impedance(314)
		  	  << " (should be 100 + 0i)"<< std::endl;
}
